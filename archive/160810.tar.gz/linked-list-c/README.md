## Linked List in C

Everything is under construction.

## Requirements
cmake 2.8.12+

## Compile Instructions
``` sh
mkdir build
cd build
cmake ..
make
```

## Execution Instructions
``` sh
cd build/demo
./demo
```

## TODO
1. Add compiler flags -Wall -Werror

