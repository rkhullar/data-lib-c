#ifndef MACROS_H
#define MACROS_H

#define T int

#endif
