## Data Lib C

Everything is under construction.

01. Basic Node
02. Doubly Linked List
03. Stack
04. Queue
05. Binary Tree
06. Binary Search Tree
07. Heap
08. Directed Graph
09. Hash Table
10. Hash Map
11. Trie

## Requirements
gcc

## Compile Instructions
``` sh
# todo
```

## Execution Instructions
``` sh
# todo
```

## TODO
1. Add compiler flags -Wall -Werror

## Troubleshoot
1. string
pointers to the stack cannot be freed. the print method calls free.

## References
1. http://www.cprogramming.com/tutorial/function-pointers.html
2. http://stackoverflow.com/questions/1472138/c-default-arguments
3. http://www.yolinux.com/TUTORIALS/LibraryArchives-StaticAndDynamic.html
4. http://www.cprogramming.com/tutorial/shared-libraries-linux-gcc.html
5. https://codeyarns.com/2014/01/14/how-to-add-library-directory-to-ldconfig-cache/
